# -*- coding: utf-8 -*-
"""Extract GSRRS 2018 country-level policy tables (A3-A12) into a tidy CSV."""
import fitz, os, re, json
import pandas as pd

OUT = r'ipdata/raw'
PROC = r'ipdata/proc'

# page ranges (1-based, inclusive) of each annex table
RANGES = {
    'post_crash': (332, 343),      # A3
    'speed': (344, 351),           # A4
    'drink': (352, 363),           # A5
    'helmet': (364, 375),          # A6
    'seatbelt': (376, 387),        # A7
    'child': (388, 396),           # A8
    'mobile': (397, 402),          # A9
    'management': (403, 409),      # A10
    'mobility': (410, 415),        # A11
    'vehicle': (416, 423),         # A12
}

doc = fitz.open(os.path.join(OUT, 'gsrrs2018.pdf'))
frames = {}
for key, (p0, p1) in RANGES.items():
    rows = []
    header = None
    for i in range(p0 - 1, p1):
        pg = doc[i]
        try:
            tabs = pg.find_tables()
        except Exception:
            continue
        for t in tabs.tables:
            try:
                ext = t.extract()
            except Exception:
                continue
            if not ext or len(ext) < 3:
                continue
            # header = first two rows joined
            hdr = [' '.join(str(ext[0][j] or '') + ' ' + str(ext[1][j] or '')).strip()
                   if j < len(ext[1]) else str(ext[0][j] or '') for j in range(len(ext[0]))]
            if header is None:
                header = hdr
            for r in ext[2:]:
                if r and r[0] and str(r[0]).strip() and not str(r[0]).startswith('Country'):
                    rows.append([str(c).strip() if c is not None else '' for c in r])
    if not rows:
        print(key, 'NO ROWS'); continue
    ncol = max(len(r) for r in rows)
    df = pd.DataFrame([r + [''] * (ncol - len(r)) for r in rows], columns=[f'c{j}' for j in range(ncol)])
    df = df.drop_duplicates()
    frames[key] = df
    print(f'{key}: {len(df)} rows, {ncol} cols | header sample: {[h[:22] for h in (header or [])[:6]]}')
doc.close()

os.makedirs(os.path.join(PROC, 'policy'), exist_ok=True)
for k, df in frames.items():
    df.to_csv(os.path.join(PROC, 'policy', f'gsrrs2018_{k}.csv'), index=False)
print('saved', len(frames), 'policy tables')
