# -*- coding: utf-8 -*-
"""Build country-level 2018 policy indicators from GSRRS 2018 annex tables."""
import pandas as pd, numpy as np, os, re

PROC = r'ipdata/proc'
PP = os.path.join(PROC, 'policy')

speed = pd.read_csv(os.path.join(PP, 'gsrrs2018_speed.csv'))
drink = pd.read_csv(os.path.join(PP, 'gsrrs2018_drink.csv'))
helmet = pd.read_csv(os.path.join(PP, 'gsrrs2018_helmet.csv'))
seatbelt = pd.read_csv(os.path.join(PP, 'gsrrs2018_seatbelt.csv'))
mobile = pd.read_csv(os.path.join(PP, 'gsrrs2018_mobile.csv'))
child = pd.read_csv(os.path.join(PP, 'gsrrs2018_child.csv'))
mgmt = pd.read_csv(os.path.join(PP, 'gsrrs2018_management.csv'))
veh = pd.read_csv(os.path.join(PP, 'gsrrs2018_vehicle.csv'))

def norm(s):
    return re.sub(r'\s+', ' ', str(s)).strip()

def clean_name(s):
    return norm(s).replace('\n', ' ')

def yn(v):
    v = norm(v).lower()
    if v.startswith('yes'):
        return True
    if v.startswith('no'):
        return False
    return None

def dedup(df, col='c0'):
    df = df.copy()
    df[col] = df[col].map(clean_name)
    return df.drop_duplicates(subset=[col], keep='first').set_index(col)

sp = dedup(speed)
dr = dedup(drink)
he = dedup(helmet)
sb = dedup(seatbelt)
mo = dedup(mobile)
ch = dedup(child)
mg = dedup(mgmt)
ve = dedup(veh)

# urban speed limit parsing -> km/h value
def parse_speed(v):
    v = norm(v)
    m = re.search(r'(\d+)\s*km', v)
    if m:
        return int(m.group(1))
    m = re.search(r'~\s*(\d+)\s*km', v)
    if m:
        return int(m.group(1))
    return None

rows = []
for country in sp.index:
    r = {'country_gsrrs': country}
    # speed
    law = yn(sp.loc[country, 'c1']) if country in sp.index else None
    urban = parse_speed(sp.loc[country, 'c3']) if country in sp.index else None
    r['speed_law'] = law
    r['urban_speed_limit'] = urban
    r['speed_bp'] = bool(law) and urban is not None and urban <= 50
    # drink
    if country in dr.index:
        r['drink_law'] = yn(dr.loc[country, 'c1'])
        bac = norm(dr.loc[country, 'c3'])
        r['bac'] = bac
        m = re.search(r'0\.0?(\d)', bac.replace('\u2264', '').replace(' ', ''))
        r['bac_val'] = float('0.0' + m.group(1)) if m else None
        r['drink_bp'] = bool(yn(dr.loc[country, 'c1'])) and r['bac_val'] is not None and r['bac_val'] <= 0.05
    else:
        r['drink_bp'] = None
    # helmet
    if country in he.index:
        r['helmet_law'] = yn(he.loc[country, 'c1'])
        r['helmet_bp'] = bool(yn(he.loc[country, 'c1'])) and bool(yn(he.loc[country, 'c2']))
    else:
        r['helmet_bp'] = None
    # seatbelt
    if country in sb.index:
        r['seatbelt_law'] = yn(sb.loc[country, 'c1'])
        all_occ = yn(sb.loc[country, 'c2']) and yn(sb.loc[country, 'c3'])
        r['seatbelt_bp'] = bool(yn(sb.loc[country, 'c1'])) and bool(all_occ)
    else:
        r['seatbelt_bp'] = None
    # mobile
    if country in mo.index:
        r['mobile_bp'] = bool(yn(mo.loc[country, 'c2']))
    else:
        r['mobile_bp'] = None
    # child restraint
    if country in ch.index:
        r['child_bp'] = yn(ch.loc[country, 'c1'])
    else:
        r['child_bp'] = None
    # management
    if country in mg.index:
        r['lead_agency'] = yn(mg.loc[country, 'c1'])
        r['strategy'] = yn(mg.loc[country, 'c6'])
    else:
        r['lead_agency'] = None; r['strategy'] = None
    # vehicle standards: count Yes across c2..c8
    if country in ve.index:
        vals = [yn(ve.loc[country, f'c{j}']) for j in range(2, 9)]
        r['vehicle_standards'] = sum(1 for v in vals if v is True)
    else:
        r['vehicle_standards'] = None
    rows.append(r)

pol = pd.DataFrame(rows)
bp_cols = ['speed_bp', 'drink_bp', 'helmet_bp', 'seatbelt_bp', 'mobile_bp', 'child_bp', 'lead_agency', 'strategy']
for c in bp_cols:
    pol[c] = pol[c].map(lambda v: np.nan if v is None else float(bool(v)))
pol['policy_score'] = pol[bp_cols].sum(axis=1, min_count=1)
pol['policy_score_with_veh'] = pol['policy_score'].fillna(0) + pol['vehicle_standards'].fillna(0) / 7

print('policy table rows:', len(pol))
print(pol[['speed_bp', 'drink_bp', 'helmet_bp', 'seatbelt_bp', 'mobile_bp', 'child_bp',
           'lead_agency', 'strategy']].mean().round(3).to_string())
print('mean policy score:', round(pol.policy_score.mean(), 2), '/', len(bp_cols))
pol.to_csv(os.path.join(PROC, 'policy', 'policy_indicators_2018.csv'), index=False)
print('saved policy indicators')
