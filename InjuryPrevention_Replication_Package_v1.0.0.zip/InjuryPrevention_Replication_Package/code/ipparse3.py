"""Parse GHE global deaths time series: cols [code, hierarchy..., Both sexes, Male, Female, age groups...]."""
import pandas as pd, os

OUT = r'ipdata/raw'
PROC = r'ipdata/proc'
f = os.path.join(OUT, 'ghe2021_deaths_global_new2.xlsx')
xl = pd.ExcelFile(f)

CODES = {0: 'All causes', 1510: 'Injuries', 1520: 'Unintentional injuries', 1530: 'Road injury',
         1540: 'Poisonings', 1550: 'Falls', 1560: 'Fire, heat and hot substances', 1570: 'Drowning',
         1575: 'Exposure to mechanical forces', 1580: 'Natural disasters', 1590: 'Other unintentional injuries',
         1600: 'Intentional injuries', 1610: 'Self-harm', 1620: 'Interpersonal violence',
         1630: 'Collective violence and legal intervention'}

rows = []
for sheet in [s for s in xl.sheet_names if s.startswith('Global')]:
    yr = int(sheet.split()[-1])
    d = xl.parse(sheet, header=None)
    # header row 6 carries age-group labels starting col 9; sex at row 5
    age_labels = {}
    for c in range(9, min(40, d.shape[1])):
        v = d.iloc[6, c]
        if isinstance(v, str) and v.strip():
            age_labels[c] = v.strip()
    for i in range(9, len(d)):
        code = d.iloc[i, 0]
        if isinstance(code, (int, float)) and not pd.isna(code) and int(code) in CODES:
            for sex, c in [('Both sexes', 6), ('Male', 7), ('Female', 8)]:
                v = d.iloc[i, c]
                if isinstance(v, (int, float)) and not pd.isna(v):
                    rows.append({'year': yr, 'sex': sex, 'ghe_code': int(code), 'cause': CODES[int(code)],
                                 'age_group': 'Total', 'deaths_000': float(v) / 1000.0})
            for c, lab in age_labels.items():
                v = d.iloc[i, c]
                if isinstance(v, (int, float)) and not pd.isna(v):
                    rows.append({'year': yr, 'sex': 'Both sexes', 'ghe_code': int(code), 'cause': CODES[int(code)],
                                 'age_group': lab, 'deaths_000': float(v) / 1000.0})

g = pd.DataFrame(rows)
g.to_csv(os.path.join(PROC, 'ghe_global_deaths_series.csv'), index=False)
tot = g[(g.age_group == 'Total')]
print(tot[tot.cause == 'Unintentional injuries'].pivot_table(index='year', columns='sex', values='deaths_000').round(1))
print('global age groups:', sorted(set(g.age_group))[:14])
print('rows:', len(g))
