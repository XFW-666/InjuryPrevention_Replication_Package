# -*- coding: utf-8 -*-
"""Event-study (parallel pre-trends test), external validation vs UN SDG, within/between inequality decomposition."""
import pandas as pd, numpy as np, os, json
import statsmodels.formula.api as smf

PROC = r'ipdata/proc'
RES = r'ipdata/results'
R = json.load(open(os.path.join(RES, 'core_results.json')))

panel = pd.read_csv(os.path.join(PROC, 'panel_persons.csv'))
_cn0 = pd.read_csv(os.path.join(PROC, 'ghe_deaths_long.csv'))[['iso3', 'country']].drop_duplicates('iso3')
panel = panel.merge(_cn0, on='iso3', how='left')
m = pd.read_csv(os.path.join(RES, 'policy_mortality_merged.csv'))

# ---------- 1. Event study: period-specific treatment effects ----------
road = panel[panel.cause == 'Road injury'][['iso3', 'year', 'asdr', 'gdp_pc', 'pop65_pct']]
dd = road.merge(m[['iso3', 'policy_score']], on='iso3', how='inner')
dd = dd[(dd.asdr > 0) & dd.asdr.notna()]
dd['la'] = np.log(dd.asdr)
dd['lgdp'] = np.log(dd.gdp_pc / 1000)
dd['ps'] = dd.policy_score
dd = dd.replace([np.inf, -np.inf], np.nan).dropna(subset=['la', 'ps', 'lgdp', 'pop65_pct'])
# period dummies: base = 2000; interactions with ps for 2010, 2015, 2019, 2020, 2021
dd['y2010'] = (dd.year == 2010).astype(int)
dd['y2015'] = (dd.year == 2015).astype(int)
dd['y2019'] = (dd.year == 2019).astype(int)
dd['y2020'] = (dd.year == 2020).astype(int)
dd['y2021'] = (dd.year == 2021).astype(int)
es = smf.ols('la ~ y2010:ps + y2015:ps + y2019:ps + y2020:ps + y2021:ps + y2010 + y2015 + y2019 + y2020 + y2021 '
             '+ lgdp + pop65_pct + C(iso3)', data=dd).fit(
    cov_type='cluster', cov_kwds={'groups': dd.iso3.astype('category').cat.codes.values})
ev = {}
for k in ['y2010:ps', 'y2015:ps', 'y2019:ps', 'y2020:ps', 'y2021:ps']:
    i = list(es.params.index).index(k)
    ev[k] = {'coef': float(es.params.iloc[i]), 'se': float(es.bse.iloc[i]),
             'p': float(es.pvalues.iloc[i]),
             'ci': [float(v) for v in es.conf_int().iloc[i].tolist()]}
print('event study (base year 2000, interaction with policy score):')
for k, v in ev.items():
    print(f"   {k}: {v['coef']:+.4f} [{v['ci'][0]:+.4f}, {v['ci'][1]:+.4f}] p={v['p']:.4f}")
R['policy']['event_study'] = ev

# ---------- 2. External validation: GHE 2021 road ASDR vs UN SDG 3.6.1 2021 ----------
unsdg = pd.read_csv(os.path.join(PROC, 'unsdg_road_traffic.csv'))
unsdg = unsdg[unsdg.year == 2021][['country', 'value']].rename(columns={'value': 'sdg_rate', 'country': 'country'})
ghe21 = panel[(panel.cause == 'Road injury') & (panel.year == 2021)][['iso3', 'country', 'asdr']].rename(columns={'asdr': 'ghe_asdr'})
val = ghe21.merge(unsdg, on='country', how='inner')
val = val.dropna(subset=['sdg_rate', 'ghe_asdr'])
val = val[(val.ghe_asdr > 0) & (val.sdg_rate > 0)]
from scipy import stats as sst
pear = sst.pearsonr(np.log(val.ghe_asdr), np.log(val.sdg_rate))
spear = sst.spearmanr(val.ghe_asdr, val.sdg_rate)
mean_diff = (val.ghe_asdr - val.sdg_rate).mean()
pct_within_20 = ((np.abs(val.ghe_asdr - val.sdg_rate) / val.sdg_rate) <= 0.20).mean() * 100
val_out = {'n': int(len(val)), 'pearson_r_log': float(pear[0]), 'pearson_p': float(pear[1]),
           'spearman_rho': float(spear[0]), 'mean_diff_per100k': float(mean_diff),
           'pct_within_20pct': float(pct_within_20)}
print('\nexternal validation (GHE vs UN SDG 2021, n=%d): r=%.3f, rho=%.3f, mean diff=%.2f/100k, %.0f%% within 20%%'
      % (val_out['n'], val_out['pearson_r_log'], val_out['spearman_rho'], val_out['mean_diff_per100k'], val_out['pct_within_20pct']))
R['external_validation'] = val_out
val.to_csv(os.path.join(RES, 'external_validation_road.csv'), index=False)

# ---------- 3. Within/between country decomposition of the concentration-index change ----------
# CI_t = between + within; use the standard decomposition on 2000 and 2021 YLL rates
def ci_parts(yr):
    d = panel[(panel.year == yr) & (panel.cause == 'Unintentional injuries')].dropna(subset=['yll_000', 'gdp_pc'])
    d = d.sort_values('gdp_pc').reset_index(drop=True)
    d['rate'] = d.yll_000 / d.ghe_pop_000 * 100
    d['rank'] = (np.cumsum(d.ghe_pop_000) / d.ghe_pop_000.sum())
    d['rank'] = (d['rank'] + (d['rank'] - d.ghe_pop_000 / d.ghe_pop_000.sum())) / 2
    # country-mean income rank proxy: use log gdp rank (between) vs country-specific deviation (within)
    d['lg'] = np.log(d.gdp_pc)
    # decompose variance of rate into between-country (explained by lg) and residual
    X = np.column_stack([np.ones(len(d)), d.lg])
    W = d.ghe_pop_000.values
    beta, *_ = np.linalg.lstsq(X * W[:, None], d.rate * W, rcond=None)
    fit = X @ beta
    resid = d.rate - fit
    mu = np.average(d.rate, weights=W)
    # CI = 2/mu * cov(rate, rank); decompose cov into explained + residual parts
    cov_tot = np.cov(d.rate, d['rank'], aweights=W)[0, 1]
    cov_bet = np.cov(fit, d['rank'], aweights=W)[0, 1]
    cov_wit = np.cov(resid, d['rank'], aweights=W)[0, 1]
    return {'CI': 2 / mu * cov_tot, 'CI_between': 2 / mu * cov_bet, 'CI_within': 2 / mu * cov_wit,
            'mu': float(mu), 'n': int(len(d))}

parts = {}
for yr in [2000, 2021]:
    parts[yr] = ci_parts(yr)
print('\nCI decomposition (between = income-explained, within = residual):')
for yr, v in parts.items():
    print(f"   {yr}: CI={v['CI']:.4f} | between={v['CI_between']:.4f} | within={v['CI_within']:.4f}")
R['ci_decomposition'] = parts

json.dump(R, open(os.path.join(RES, 'core_results.json'), 'w'), indent=1, default=str)
print('\nsaved event study, external validation, CI decomposition')
