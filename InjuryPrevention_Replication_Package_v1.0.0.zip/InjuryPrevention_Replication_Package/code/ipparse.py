"""Parse WHO GHE 2021 files into tidy CSVs."""
import pandas as pd, os, numpy as np, json

OUT = r'ipdata/raw'
PROC = r'ipdata/proc'
os.makedirs(PROC, exist_ok=True)

CODES = {
    0: 'All causes', 1510: 'Injuries', 1520: 'Unintentional injuries', 1530: 'Road injury',
    1540: 'Poisonings', 1550: 'Falls', 1560: 'Fire, heat and hot substances', 1570: 'Drowning',
    1575: 'Exposure to mechanical forces', 1580: 'Natural disasters', 1590: 'Other unintentional injuries',
    1600: 'Intentional injuries', 1610: 'Self-harm', 1620: 'Interpersonal violence',
    1630: 'Collective violence and legal intervention',
}

def parse_wide(path, sheet, value_label):
    """Parse a wide GHE sheet: rows=causes x 3 sex blocks, cols=countries. Returns long df."""
    d = pd.read_excel(path, sheet_name=sheet, header=None)
    # column 0 carries the sex tag on every cause row; blocks are contiguous Persons/Males/Females
    sex_seq = [(i, str(d.iloc[i, 0]).strip()) for i in range(len(d))
               if isinstance(d.iloc[i, 0], str) and d.iloc[i, 0].strip() in ('Persons', 'Males', 'Females')]
    blocks = {}
    for i, s in sex_seq:
        if s not in blocks:
            blocks[s] = [i, i]
        else:
            blocks[s][1] = i
    # country columns
    name_row, iso_row = 6, 7
    cols = {}
    for c in range(7, d.shape[1]):
        iso = d.iloc[iso_row, c]
        nm = d.iloc[name_row, c]
        if isinstance(iso, str) and len(iso.strip()) == 3 and iso.strip().isalpha():
            cols[c] = (iso.strip(), str(nm).strip() if isinstance(nm, str) else iso.strip())
    out = []
    for sex, (r0, r1) in blocks.items():
        for i in range(r0, r1 + 1):
            code = d.iloc[i, 1]
            if isinstance(code, (int, float)) and not pd.isna(code):
                ic = int(code)
                if ic not in CODES:
                    continue
                for c, (iso, nm) in cols.items():
                    v = d.iloc[i, c]
                    if isinstance(v, (int, float)) and not pd.isna(v):
                        out.append((sex, iso, nm, ic, CODES[ic], float(v)))
    return pd.DataFrame(out, columns=['sex', 'iso3', 'country', 'ghe_code', 'cause', value_label])

def population_table(path, sheet):
    d = pd.read_excel(path, sheet_name=sheet, header=None)
    iso_row = 7
    row_pop = None
    for i in range(len(d)):
        if str(d.iloc[i, 3]).strip().startswith('Population'):
            row_pop = i
            break
    recs = []
    for c in range(7, d.shape[1]):
        iso = d.iloc[iso_row, c]
        if isinstance(iso, str) and len(iso.strip()) == 3 and iso.strip().isalpha():
            nm = d.iloc[6, c]
            v = d.iloc[row_pop, c] if row_pop else None
            if isinstance(v, (int, float)) and not pd.isna(v):
                recs.append((iso.strip(), str(nm).strip(), float(v)))
    return pd.DataFrame(recs, columns=['iso3', 'country', 'pop_000'])

# 1. Deaths by country: years 2000, 2015, 2019, 2021
frames = {}
for yr, fn in [(2000, 'ghe2021_deaths_bycountry_2000.xlsx'), (2015, 'ghe2021_deaths_bycountry_2015.xlsx'),
               (2019, 'ghe2021_deaths_bycountry_2019.xlsx'), (2021, 'ghe2021_deaths_bycountry_2021.xlsx')]:
    p = os.path.join(OUT, fn)
    df = parse_wide(p, 'All ages', 'deaths_000')
    df['year'] = yr
    df['gdp'] = None
    frames[(yr, 'deaths')] = df
    print(yr, 'deaths rows', len(df), 'countries', df.iso3.nunique(), flush=True)

# ASDR: 2000, 2010, 2015, 2019, 2020, 2021
p_asdr = os.path.join(OUT, 'ghe2021_deathrates_bycountry_asdr.xlsx')
asdr_frames = []
for yr in [2000, 2010, 2015, 2019, 2020, 2021]:
    df = parse_wide(p_asdr, f'ASDR {yr}', 'asdr')
    df['year'] = yr
    asdr_frames.append(df)
    print('ASDR', yr, 'rows', len(df), flush=True)

# YLL: 2000, 2019, 2021
yll_frames = []
for yr, fn in [(2000, 'ghe2021_yll_bycountry_2000.xlsx'), (2019, 'ghe2021_yll_bycountry_2019.xlsx'), (2021, 'ghe2021_yll_bycountry_2021.xlsx')]:
    df = parse_wide(os.path.join(OUT, fn), 'All ages', 'yll_000')
    df['year'] = yr
    yll_frames.append(df)
    print('YLL', yr, 'rows', len(df), flush=True)

# save
all_deaths = pd.concat(frames.values(), ignore_index=True)
all_deaths.to_csv(os.path.join(PROC, 'ghe_deaths_long.csv'), index=False)
pd.concat(asdr_frames, ignore_index=True).to_csv(os.path.join(PROC, 'ghe_asdr_long.csv'), index=False)
pd.concat(yll_frames, ignore_index=True).to_csv(os.path.join(PROC, 'ghe_yll_long.csv'), index=False)

# population per year (from each year's file)
pops = {}
for yr, fn in [(2000, 'ghe2021_deaths_bycountry_2000.xlsx'), (2010, 'ghe2021_deathrates_bycountry_asdr.xlsx'),
               (2015, 'ghe2021_deaths_bycountry_2015.xlsx'), (2019, 'ghe2021_deathrates_bycountry_asdr.xlsx'),
               (2020, 'ghe2021_deathrates_bycountry_asdr.xlsx'), (2021, 'ghe2021_deaths_bycountry_2021.xlsx')]:
    sheet = 'All ages' if 'deaths_bycountry' in fn else f'ASDR {yr}'
    pt = population_table(os.path.join(OUT, fn), sheet)
    pt['year'] = yr
    pops[yr] = pt
pop_all = pd.concat(pops.values(), ignore_index=True)
pop_all.to_csv(os.path.join(PROC, 'ghe_population.csv'), index=False)
print('population rows', len(pop_all), flush=True)

# 2. Age-group sheets from 2021 country file
age_sheets = ['0-4', '5-14', '15-29', '30-49', '50-59', '60-69', '70+']
aframes = []
for s in age_sheets:
    df = parse_wide(os.path.join(OUT, 'ghe2021_deaths_bycountry_2021.xlsx'), s, 'deaths_000')
    df['age_group'] = s
    aframes.append(df)
    print('age', s, 'rows', len(df), flush=True)
pd.concat(aframes, ignore_index=True).to_csv(os.path.join(PROC, 'ghe_agegroup_2021.csv'), index=False)
print('DONE')
