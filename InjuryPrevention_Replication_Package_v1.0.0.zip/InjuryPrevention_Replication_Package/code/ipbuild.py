"""Build master panel dataset for the Injury Prevention paper."""
import pandas as pd, numpy as np, os, json

PROC = r'ipdata/proc'
OUT = r'ipdata/raw'

MECHS = ['Road injury', 'Poisonings', 'Falls', 'Fire, heat and hot substances', 'Drowning',
         'Exposure to mechanical forces', 'Natural disasters', 'Other unintentional injuries']

deaths = pd.read_csv(os.path.join(PROC, 'ghe_deaths_long.csv'))
asdr = pd.read_csv(os.path.join(PROC, 'ghe_asdr_long.csv'))
yll = pd.read_csv(os.path.join(PROC, 'ghe_yll_long.csv'))
pop = pd.read_csv(os.path.join(PROC, 'ghe_population.csv'))
reg = pd.read_csv(os.path.join(PROC, 'who_region_map.csv'))
meta = pd.read_csv(os.path.join(PROC, 'wb_country_meta.csv'))

# long panel for selected causes (Persons only for main; sexes kept for sex analyses)
keep = MECHS + ['Unintentional injuries', 'All causes', 'Intentional injuries']
deaths = deaths[deaths.cause.isin(keep) & (deaths.sex == 'Persons')].copy()
asdr = asdr[asdr.cause.isin(keep) & (asdr.sex == 'Persons')].copy()
yll = yll[yll.cause.isin(keep) & (yll.sex == 'Persons')].copy()

# covariates from WB raw json
wb_files = {
    'gdp_pc': 'wb_gdp_pc_ppp.json', 'urban_pct': 'wb_urban_pct.json', 'pop65_pct': 'wb_pop_65up_pct.json',
    'pop0014_pct': 'wb_pop_0014_pct.json', 'alcohol': 'wb_alcohol.json', 'health_exp': 'wb_health_exp.json',
    'physicians': 'wb_physicians.json', 'internet': 'wb_internet.json', 'life_exp': 'wb_life_exp.json',
    'pop_total': 'wb_pop_total.json',
}
covs = None
for k, fn in wb_files.items():
    j = json.load(open(os.path.join(OUT, fn)))
    df = pd.DataFrame(j['rows'])[['iso3', 'year', 'value']].rename(columns={'value': k})
    covs = df if covs is None else covs.merge(df, on=['iso3', 'year'], how='outer')

YEARS = [2000, 2010, 2015, 2019, 2020, 2021]

# base grid: iso3 x year
iso3s = sorted(deaths.iso3.unique())
base = pd.MultiIndex.from_product([iso3s, YEARS], names=['iso3', 'year']).to_frame(index=False)

# asdr: all 6 years; deaths: 2000/2015/2019/2021; yll: 2000/2019/2021
asdr_l = asdr[['iso3', 'year', 'cause', 'asdr']].rename(columns={'asdr': 'asdr'})
deaths_l = deaths[['iso3', 'year', 'cause', 'deaths_000']].rename(columns={'deaths_000': 'deaths_000'})
yll_l = yll[['iso3', 'year', 'cause', 'yll_000']].rename(columns={'yll_000': 'yll_000'})

panel = base.merge(asdr_l, on=['iso3', 'year'], how='left').merge(deaths_l, on=['iso3', 'year', 'cause'], how='left').merge(yll_l, on=['iso3', 'year', 'cause'], how='left')
panel = panel.merge(covs, on=['iso3', 'year'], how='left')
panel = panel.merge(reg, on='iso3', how='left')
panel = panel.merge(meta[['iso3', 'region', 'income']].rename(columns={'region': 'wb_region', 'income': 'wb_income'}), on='iso3', how='left')

# population from GHE (per year) and WB
pop_ghe = pop[['iso3', 'year', 'pop_000']].rename(columns={'pop_000': 'ghe_pop_000'})
panel = panel.merge(pop_ghe, on=['iso3', 'year'], how='left')

# forward-fill covariates within country (documented): for each iso, ffill/bfill
cov_cols = ['gdp_pc', 'urban_pct', 'pop65_pct', 'pop0014_pct', 'alcohol', 'health_exp', 'physicians', 'internet', 'life_exp', 'pop_total']
panel = panel.sort_values(['iso3', 'year'])
for c in cov_cols:
    panel[c] = panel.groupby('iso3')[c].transform(lambda s: s.ffill().bfill())

panel.to_csv(os.path.join(PROC, 'panel_persons.csv'), index=False)

# quick sanity
chk = panel[(panel.cause == 'Unintentional injuries') & (panel.year == 2021)]
print('panel rows:', len(panel), '| 2021 unintentional deaths (000):', round(chk.deaths_000.sum(), 1),
      '| countries with ASDR:', chk.asdr.notna().sum(), '| with gdp:', chk.gdp_pc.notna().sum())
chk00 = panel[(panel.cause == 'Unintentional injuries') & (panel.year == 2000)]
print('2000 unintentional deaths (000):', round(chk00.deaths_000.sum(), 1), '| countries:', chk00.asdr.notna().sum())
print('DONE')
