"""Core analyses for the Injury Prevention paper. Saves results to JSON/CSV."""
import pandas as pd, numpy as np, os, json
from scipy import stats
import statsmodels.formula.api as smf
import statsmodels.api as sm

PROC = r'ipdata/proc'
RES = r'ipdata/results'
os.makedirs(RES, exist_ok=True)
R = {}  # results dict

MECHS = ['Road injury', 'Poisonings', 'Falls', 'Fire, heat and hot substances', 'Drowning',
         'Exposure to mechanical forces', 'Natural disasters', 'Other unintentional injuries']
panel = pd.read_csv(os.path.join(PROC, 'panel_persons.csv'))
age21 = pd.read_csv(os.path.join(PROC, 'ghe_agegroup_2021.csv'))
pop_age = pd.read_csv(os.path.join(PROC, 'ghe_agegroup_population.csv'))
d00 = pd.read_csv(os.path.join(PROC, 'ghe_deaths_long.csv'))
y00 = pd.read_csv(os.path.join(PROC, 'ghe_yll_long.csv'))
a00 = pd.read_csv(os.path.join(PROC, 'ghe_asdr_long.csv'))

# ---------- A. Mechanism summary (Table 1) ----------
rows = []
AGE_MID = {'0-4': 2.5, '5-14': 10, '15-29': 22.5, '30-49': 40, '50-59': 55, '60-69': 65, '70+': 77.5}
for cause in ['Unintentional injuries'] + MECHS:
    rec = {'cause': cause}
    for yr in [2000, 2015, 2019, 2021]:
        sub = panel[(panel.cause == cause) & (panel.year == yr)]
        rec[f'deaths_{yr}'] = sub.deaths_000.sum()
        rec[f'asdr_{yr}'] = np.average(sub.asdr.dropna(), weights=None) if sub.asdr.notna().any() else np.nan
        # population-weighted global ASDR
        d_ = sub.dropna(subset=['asdr', 'ghe_pop_000'])
        rec[f'asdr_{yr}'] = np.average(d_.asdr, weights=d_.ghe_pop_000) if len(d_) else np.nan
        rec[f'crude_{yr}'] = np.average(sub.deaths_000 / sub.ghe_pop_000 * 100, weights=None) if sub.deaths_000.notna().any() else np.nan
        d2 = sub.dropna(subset=['deaths_000', 'ghe_pop_000'])
        rec[f'crude_{yr}'] = d2.deaths_000.sum() / d2.ghe_pop_000.sum() * 100 if len(d2) else np.nan
    for yr in [2000, 2019, 2021]:
        sub = panel[(panel.cause == cause) & (panel.year == yr)]
        rec[f'yll_{yr}'] = sub.yll_000.sum()
    # crude 2000 & change
    rec['deaths_pct_change'] = (rec['deaths_2021'] / rec['deaths_2000'] - 1) * 100
    rec['asdr_pct_change'] = (rec['asdr_2021'] / rec['asdr_2000'] - 1) * 100
    rec['yll_pct_change'] = (rec['yll_2021'] / rec['yll_2000'] - 1) * 100
    rec['yll_per_death_2021'] = rec['yll_2021'] / rec['deaths_2021']
    # share of unintentional 2021
    rows.append(rec)
summ = pd.DataFrame(rows)
tot_unint = summ.loc[summ.cause == 'Unintentional injuries', 'deaths_2021'].iloc[0]
summ['share_of_unint_2021'] = summ['deaths_2021'] / tot_unint * 100
# sex-specific 2021 (from raw deaths/yll long)
def sex_agg(cause, sex, yr, val):
    src = {'deaths': d00, 'yll': y00, 'asdr': a00}[val]
    s = src[(src.cause == cause) & (src.sex == sex) & (src.year == yr)]
    return s[val + '_000'].sum() if val != 'asdr' else np.average(s.asdr, weights=None)
summ['deaths_2021_m'] = summ.cause.map(lambda c: sex_agg(c, 'Males', 2021, 'deaths'))
summ['deaths_2021_f'] = summ.cause.map(lambda c: sex_agg(c, 'Females', 2021, 'deaths'))
summ['mf_ratio_2021'] = summ['deaths_2021_m'] / summ['deaths_2021_f']
summ['deaths_2021_m_share'] = summ['deaths_2021_m'] / summ['deaths_2021'] * 100
# mean age at death 2021 (from age-group deaths)
ma_rows = []
for cause in ['Unintentional injuries'] + MECHS:
    sub = age21[(age21.cause == cause) & (age21.sex == 'Persons')]
    if len(sub) == 0:
        continue
    d = sub.groupby('age_group').deaths_000.sum()
    m = sum(d.get(k, 0) * v for k, v in AGE_MID.items())
    tot = d.sum()
    ma_rows.append({'cause': cause, 'mean_age_death_2021': m / tot})
ma = pd.DataFrame(ma_rows)
summ = summ.merge(ma, on='cause', how='left')
summ.to_csv(os.path.join(RES, 'table1_mechanism_summary.csv'), index=False)
R['table1'] = summ.to_dict('records')
print('A. mechanism summary done')

# ---------- B. Kitagawa decomposition ----------
BROAD = {'0-4': '0-14', '5-14': '0-14', '15-29': '15-64', '30-49': '15-64', '50-59': '15-64',
         '60-69': '15-64', '70+': '65+'}
pop_age['broad'] = pop_age.age_group.map(BROAD)
popp = pop_age.groupby(['year', 'iso3', 'broad']).population_000.sum().reset_index()

def kitagawa(deaths_src, cause, value='deaths_000'):
    """deaths_src: df with iso3, age_group, deaths_000; global 3-age-group decomposition."""
    d = deaths_src[deaths_src.cause == cause].copy()
    d['broad'] = d.age_group.map(BROAD)
    dg = d.groupby(['year', 'iso3', 'broad'])[value].sum().reset_index().rename(columns={value: 'D'})
    m = dg.merge(popp, on=['year', 'iso3', 'broad'], how='inner')
    # global rate per age group
    g = m.groupby(['year', 'broad']).agg(D=('D', 'sum'), P=('population_000', 'sum')).reset_index()
    g['r'] = g.D / g.P  # deaths per capita
    g0 = g[g.year == 2000].set_index('broad')
    g1 = g[g.year == 2021].set_index('broad')
    out = {}
    tot = {'pop_effect': 0.0, 'rate_effect': 0.0, 'interaction': 0.0, 'D0': 0.0, 'D1': 0.0}
    for a in g0.index:
        P0, P1 = g0.loc[a, 'P'], g1.loc[a, 'P']
        r0, r1 = g0.loc[a, 'r'], g1.loc[a, 'r']
        pe = (P1 - P0) * r0
        re = (r1 - r0) * P0
        it = (P1 - P0) * (r1 - r0)
        out[a] = {'P0': P0, 'P1': P1, 'r0': r0, 'r1': r1, 'pop_effect': pe, 'rate_effect': re, 'interaction': it,
                  'D0': g0.loc[a, 'D'], 'D1': g1.loc[a, 'D']}
        tot['pop_effect'] += pe; tot['rate_effect'] += re; tot['interaction'] += it
        tot['D0'] += g0.loc[a, 'D']; tot['D1'] += g1.loc[a, 'D']
    return out, tot

age00 = pd.read_csv(os.path.join(PROC, 'ghe_agegroup_2000_2021.csv'))
age00 = age00[age00.sex == 'Persons']  # avoid Persons+Males+Females triple counting
kresults = {}
for cause in ['Unintentional injuries'] + MECHS + ['All causes']:
    detail, tot = kitagawa(age00, cause)
    kresults[cause] = {'detail': {k: {kk: float(vv) for kk, vv in v.items()} for k, v in detail.items()},
                       'total': {k: float(v) for k, v in tot.items()}}
# YLL decomposition with same structure (YLL per capita by age group)
yll_age = None  # yll by age group not available globally; use deaths-based only
R['kitagawa'] = kresults
print('B. kitagawa done:', {k: round(v['total']['D1'] - v['total']['D0'], 1) for k, v in kresults.items()})

json.dump(R, open(os.path.join(RES, 'core_results.json'), 'w'), indent=1, default=str)
summ.to_json(os.path.join(RES, 'summary.json'), orient='records', indent=1)
print('saved A+B')
