# -*- coding: utf-8 -*-
"""Policy-outcome analysis v2: level models, ARR models, and a pre/post-2018 difference-in-differences."""
import pandas as pd, numpy as np, os, json
import statsmodels.formula.api as smf

PROC = r'ipdata/proc'
RES = r'ipdata/results'
R = json.load(open(os.path.join(RES, 'core_results.json')))

panel = pd.read_csv(os.path.join(PROC, 'panel_persons.csv'))
m = pd.read_csv(os.path.join(RES, 'policy_mortality_merged.csv'))

BP = ['speed_bp', 'drink_bp', 'helmet_bp', 'seatbelt_bp', 'mobile_bp', 'child_bp', 'lead_agency', 'strategy']

def clean(df, cols):
    df = df.replace([np.inf, -np.inf], np.nan).dropna(subset=cols)
    return df

# (a) level model
m2 = clean(m, ['asdr21', 'lgdp', 'pop65_21', 'policy_score'])
mod_a = smf.ols('np.log(asdr21) ~ policy_score + lgdp + pop65_21', data=m2).fit(
    cov_type='cluster', cov_kwds={'groups': m2.who_region.astype('category').cat.codes.values})

# (b) ARR model
m2b = clean(m, ['arrr', 'lbasdr', 'lgdp', 'policy_score'])
mod_b = smf.ols('arrr ~ policy_score + lbasdr + lgdp', data=m2b).fit(
    cov_type='cluster', cov_kwds={'groups': m2b.who_region.astype('category').cat.codes.values})

# (c) individual laws vs ARR
m3 = clean(m, ['arrr'] + BP + ['lbasdr', 'lgdp'])
mod_c = smf.ols('arrr ~ ' + ' + '.join(BP) + ' + lbasdr + lgdp', data=m3).fit(
    cov_type='cluster', cov_kwds={'groups': m3.who_region.astype('category').cat.codes.values})

# (d) unintentional injuries level
mod_d = smf.ols('np.log(u21) ~ policy_score + lgdp + pop65_21', data=m2).fit(
    cov_type='cluster', cov_kwds={'groups': m2.who_region.astype('category').cat.codes.values})

# (e) difference-in-differences: road-injury ASDR pre (2000-2015) vs post (2015-2021), by policy score
road = panel[panel.cause == 'Road injury'][['iso3', 'year', 'asdr', 'gdp_pc', 'pop65_pct', 'who_region']]
dd = road.merge(m[['iso3', 'policy_score'] + BP], on='iso3', how='inner')
dd = dd[(dd.asdr > 0) & dd.asdr.notna()]
dd['post'] = (dd.year >= 2015).astype(int)
dd['la'] = np.log(dd.asdr)
dd['lgdp'] = np.log(dd.gdp_pc / 1000)
dd['ps'] = dd.policy_score
dd = dd.replace([np.inf, -np.inf], np.nan).dropna(subset=['la', 'ps', 'lgdp', 'pop65_pct'])
print('DiD rows:', len(dd), 'countries:', dd.iso3.nunique())
# DiD: la ~ post*ps + covariates + country FE + year FE
mod_did = smf.ols('la ~ post * ps + lgdp + pop65_pct + C(iso3) + C(year)', data=dd).fit(
    cov_type='cluster', cov_kwds={'groups': dd.iso3.astype('category').cat.codes.values})
i = list(mod_did.params.index).index('post:ps')
did_coef = mod_did.params.iloc[i]
did_ci = mod_did.conf_int().iloc[i].tolist()
did_p = mod_did.pvalues.iloc[i]

# also a binary split at the median policy score
med = m.policy_score.median()
dd['high'] = (dd.ps >= med).astype(int)
mod_did2 = smf.ols('la ~ post * high + lgdp + pop65_pct + C(iso3) + C(year)', data=dd).fit(
    cov_type='cluster', cov_kwds={'groups': dd.iso3.astype('category').cat.codes.values})
j = list(mod_did2.params.index).index('post:high')
did2_coef = mod_did2.params.iloc[j]
did2_ci = mod_did2.conf_int().iloc[j].tolist()
did2_p = mod_did2.pvalues.iloc[j]

def row(mod, name, label):
    i = list(mod.params.index).index(name)
    return {'label': label, 'coef': float(mod.params.iloc[i]), 'se': float(mod.bse.iloc[i]),
            'p': float(mod.pvalues.iloc[i]),
            'ci': [float(v) for v in mod.conf_int().iloc[i].tolist()]}

out = {
    'n_level': int(len(m2)), 'n_arr': int(len(m2b)), 'n_did': int(len(dd)),
    'mod_a': row(mod_a, 'policy_score', 'log road ASDR 2021'),
    'mod_b': row(mod_b, 'policy_score', 'road ARR 2015-2021 (%/yr)'),
    'mod_d': row(mod_d, 'policy_score', 'log unintentional ASDR 2021'),
    'individual': {c: row(mod_c, c, c) for c in BP},
    'did_score': {'coef': float(did_coef), 'ci': did_ci, 'p': float(did_p)},
    'did_high': {'coef': float(did2_coef), 'ci': did2_ci, 'p': float(did2_p),
                 'median_score': float(med)},
}
R['policy'] = out
json.dump(R, open(os.path.join(RES, 'core_results.json'), 'w'), indent=1, default=str)

print('(a) log road ASDR 2021 ~ policy:', {k: round(v, 4) if isinstance(v, float) else v for k, v in out['mod_a'].items()})
print('(b) road ARR ~ policy:', {k: round(v, 4) if isinstance(v, float) else v for k, v in out['mod_b'].items()})
print('(d) log unint ASDR 2021 ~ policy:', {k: round(v, 4) if isinstance(v, float) else v for k, v in out['mod_d'].items()})
print('DiD (continuous score):', out['did_score'])
print('DiD (above median):', out['did_high'])
print('individual laws:')
for c, v in out['individual'].items():
    print(f"   {c:12s} coef={v['coef']:+.3f} p={v['p']:.3f}")
