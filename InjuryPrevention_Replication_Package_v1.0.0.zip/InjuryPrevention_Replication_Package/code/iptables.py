"""Generate tables 2-4 (CSV) for the manuscript."""
import pandas as pd, numpy as np, os, json

PROC = r'ipdata/proc'
RES = r'ipdata/results'
panel = pd.read_csv(os.path.join(PROC, 'panel_persons.csv'))
sdg = pd.read_csv(os.path.join(RES, 'sdg_road_country.csv'))
regdf = pd.read_csv(os.path.join(RES, 'panel_regression.csv'))
MECHS = ['Road injury', 'Poisonings', 'Falls', 'Fire, heat and hot substances', 'Drowning',
         'Exposure to mechanical forces', 'Natural disasters', 'Other unintentional injuries']
REG_ORDER = ['AFR', 'AMR', 'EMR', 'EUR', 'SEAR', 'WPR']
REG_NAME = {'AFR': 'Africa', 'AMR': 'Americas', 'EMR': 'Eastern Mediterranean', 'EUR': 'Europe',
            'SEAR': 'South-East Asia', 'WPR': 'Western Pacific'}

# ---------- Table 2: regional summary ----------
rows = []
for reg in REG_ORDER:
    d0 = panel[(panel.who_region == reg) & (panel.cause == 'Unintentional injuries') & (panel.year == 2000)]
    d1 = panel[(panel.who_region == reg) & (panel.cause == 'Unintentional injuries') & (panel.year == 2021)]
    a0 = np.average(d0.asdr, weights=d0.ghe_pop_000)
    a1 = np.average(d1.asdr, weights=d1.ghe_pop_000)
    # top 3 mechanisms 2021
    tops = []
    for m in MECHS:
        dd = panel[(panel.who_region == reg) & (panel.cause == m) & (panel.year == 2021)]
        tops.append((m, dd.deaths_000.sum()))
    tops.sort(key=lambda x: -x[1])
    top3 = '; '.join(f'{m.replace("Fire, heat and hot substances", "Fire/heat").replace("Exposure to mechanical forces", "Mechanical forces").replace("Other unintentional injuries", "Other")} ({v:.0f}k)' for m, v in tops[:3])
    yll21 = panel[(panel.who_region == reg) & (panel.cause == 'Unintentional injuries') & (panel.year == 2021)].yll_000.sum()
    sdgr = sdg[sdg.who_region == reg]
    n_on = int((sdgr.sdg_status == 'On track').sum())
    rows.append({
        'WHO region': REG_NAME[reg],
        'Countries': int(d1.iso3.nunique()),
        'Deaths 2000 (000)': round(d0.deaths_000.sum(), 0),
        'Deaths 2021 (000)': round(d1.deaths_000.sum(), 0),
        'Deaths change (%)': round((d1.deaths_000.sum() / d0.deaths_000.sum() - 1) * 100, 1),
        'ASDR 2000': round(a0, 1),
        'ASDR 2021': round(a1, 1),
        'ASDR change (%)': round((a1 / a0 - 1) * 100, 1),
        'YLL 2021 (000)': round(yll21, 0),
        'Top 3 mechanisms 2021': top3,
        'Road SDG on track (n/N)': f'{n_on}/{len(sdgr)}',
    })
t2 = pd.DataFrame(rows)
t2.to_csv(os.path.join(RES, 'table2_regional.csv'), index=False)
print(t2[['WHO region', 'Deaths 2000 (000)', 'Deaths 2021 (000)', 'Deaths change (%)', 'ASDR 2000', 'ASDR 2021', 'ASDR change (%)', 'YLL 2021 (000)', 'Road SDG on track (n/N)']].to_string(index=False))
print()

# ---------- Table 3: panel regression ----------
VAR_LABEL = {'lg': 'log GDP pc', 'urban_pct': 'Urban %', 'pop65_pct': 'Pop 65+ %', 'alcohol': 'Alcohol L/cap',
             'health_exp': 'Health exp %GDP', 'internet': 'Internet %'}
t3 = []
for cause in ['Unintentional injuries'] + MECHS:
    row = {'Mechanism': cause.replace('Fire, heat and hot substances', 'Fire/heat').replace(
        'Exposure to mechanical forces', 'Mechanical forces').replace('Other unintentional injuries', 'Other')}
    for v, lab in VAR_LABEL.items():
        r = regdf[(regdf.cause == cause) & (regdf['var'] == v)]
        if len(r):
            star = '***' if r.p.iloc[0] < 0.001 else ('**' if r.p.iloc[0] < 0.01 else ('*' if r.p.iloc[0] < 0.05 else ''))
            row[lab] = f"{r.coef.iloc[0]:+.3f}{star} [{r.ci_low.iloc[0]:+.3f}, {r.ci_high.iloc[0]:+.3f}]"
    r = regdf[(regdf.cause == cause)]
    row['n (country-years)'] = int(r.n.iloc[0]) if len(r) else None
    t3.append(row)
t3 = pd.DataFrame(t3)
t3.to_csv(os.path.join(RES, 'table3_panel_regression.csv'), index=False)
print(t3.to_string(index=False))
print()

# ---------- Table 4: country extremes + SDG summary ----------
u = panel[panel.cause == 'Unintentional injuries']
a0 = u[u.year == 2000].set_index('iso3').asdr
a1 = u[u.year == 2021].set_index('iso3').asdr
chg = ((a1 / a0 - 1) * 100).dropna().sort_values()
cn = pd.read_csv(os.path.join(PROC, 'ghe_deaths_long.csv'))[['iso3', 'country']].drop_duplicates('iso3').set_index('iso3').country
ext = []
for iso in chg.nlargest(10).index:
    ext.append({'Direction': 'Largest ASDR increases', 'Country': cn.get(iso, iso),
                'ASDR 2000': round(a0[iso], 2), 'ASDR 2021': round(a1[iso], 2), 'Change (%)': round(chg[iso], 1)})
for iso in chg.nsmallest(10).index:
    ext.append({'Direction': 'Largest ASDR decreases', 'Country': cn.get(iso, iso),
                'ASDR 2000': round(a0[iso], 2), 'ASDR 2021': round(a1[iso], 2), 'Change (%)': round(chg[iso], 1)})
t4a = pd.DataFrame(ext)
t4a.to_csv(os.path.join(RES, 'table4a_extremes.csv'), index=False)
print(t4a.to_string(index=False))
print()
# SDG extremes
sdg['chg'] = (sdg.asdr_2021 / sdg.asdr_2015 - 1) * 100
worst = sdg.nlargest(8, 'chg')[['country', 'asdr_2015', 'asdr_2021', 'chg', 'arrr_obs_pct', 'sdg_status']]
best = sdg.nsmallest(8, 'chg')[['country', 'asdr_2015', 'asdr_2021', 'chg', 'arrr_obs_pct', 'sdg_status']]
print('WORST road injury 2015-2021:'); print(worst.round(2).to_string(index=False))
print(); print('BEST:'); print(best.round(2).to_string(index=False))
worst.to_csv(os.path.join(RES, 'table4b_sdg_worst.csv'), index=False)
best.to_csv(os.path.join(RES, 'table4c_sdg_best.csv'), index=False)
print()
print('SDG status counts:', sdg.sdg_status.value_counts().to_dict())
