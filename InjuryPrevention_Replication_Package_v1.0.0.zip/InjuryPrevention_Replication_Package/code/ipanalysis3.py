"""Analyses F-H: typology clustering, panel regression, 2030 scenarios."""
import pandas as pd, numpy as np, os, json
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score, adjusted_rand_score
from scipy import stats
import statsmodels.formula.api as smf

PROC = r'ipdata/proc'
RES = r'ipdata/results'
R = json.load(open(os.path.join(RES, 'core_results.json')))
rng = np.random.default_rng(7)

MECHS = ['Road injury', 'Poisonings', 'Falls', 'Fire, heat and hot substances', 'Drowning',
         'Exposure to mechanical forces', 'Natural disasters', 'Other unintentional injuries']
panel = pd.read_csv(os.path.join(PROC, 'panel_persons.csv'))
_cn = pd.read_csv(os.path.join(PROC, 'ghe_deaths_long.csv'))[['iso3', 'country']].drop_duplicates('iso3')
panel = panel.merge(_cn, on='iso3', how='left')

# ---------- F. Typology clustering (2021, 8 mechanisms ASDR + income + aging) ----------
w = panel[panel.year == 2021].pivot_table(index='iso3', columns='cause', values='asdr')
feat = pd.DataFrame(index=w.index)
for m in MECHS:
    feat[m] = np.log10(w[m].clip(lower=0.01))
cov = panel[panel.year == 2021].drop_duplicates('iso3').set_index('iso3')
feat['gdp'] = np.log10(cov['gdp_pc'])
feat['pop65'] = cov['pop65_pct']
feat = feat.dropna()
feat['who_region'] = cov.loc[feat.index, 'who_region']
X = StandardScaler().fit_transform(feat[MECHS + ['gdp', 'pop65']].values)
# silhouette curve for k=2..7; select k=4 (near-plateau, interpretable typology)
sil_scores = {}
kms = {}
for k in range(2, 8):
    km = KMeans(n_clusters=k, n_init=25, random_state=7).fit(X)
    sil_scores[k] = float(silhouette_score(X, km.labels_))
    kms[k] = km
kbest = 4
km = kms[kbest]
sc = sil_scores[kbest]
feat['cluster'] = km.labels_.astype(int)
# order clusters by road injury ASDR
order = feat.groupby('cluster')[['Road injury', 'Falls', 'Drowning', 'Poisonings']].mean().sort_values('Road injury').index.tolist()
remap = {c: i for i, c in enumerate(order)}
feat['cluster'] = feat.cluster.map(remap)
# bootstrap stability
aris = []
for b in range(200):
    idx = rng.integers(0, len(X), len(X))
    kb = KMeans(n_clusters=kbest, n_init=10, random_state=b).fit(X[idx])
    lab = np.full(len(X), -1)
    lab[idx] = kb.labels_
    aris.append(adjusted_rand_score(kbest and km.predict(X), lab))
feat['who_region'] = cov.loc[feat.index, 'who_region']
feat_out = feat[MECHS + ['gdp', 'pop65']].copy()
feat_out.columns = ['asdr_' + m for m in MECHS] + ['log10_gdp', 'pop65_pct']
feat_out['cluster'] = feat['cluster']
feat_out['gdp_pc'] = cov.loc[feat.index, 'gdp_pc'].values
feat_out['who_region'] = feat['who_region']
feat_out.to_csv(os.path.join(RES, 'clusters_2021.csv'))
# cluster profiles (population-weighted mechanism shares)
c21 = panel[(panel.year == 2021)].merge(feat[['cluster']], on='iso3', how='inner')
prof = []
for cl, g in c21.groupby('cluster'):
    u = g[g.cause == 'Unintentional injuries']
    row = {'cluster': cl, 'n_countries': g.iso3.nunique()}
    for m in MECHS:
        dm = g[g.cause == m].set_index('iso3').deaths_000
        du = u.set_index('iso3').deaths_000
        common = dm.index.intersection(du.index)
        row[m + '_share'] = (dm.loc[common].sum() / du.loc[common].sum()) * 100
    row['unint_cdr'] = u.deaths_000.sum() / u.ghe_pop_000.sum() * 100
    row['mean_gdp'] = g.gdp_pc.mean()
    row['mean_pop65'] = g.pop65_pct.mean()
    prof.append(row)
prof = pd.DataFrame(prof).sort_values('cluster')
prof.to_csv(os.path.join(RES, 'cluster_profiles.csv'), index=False)
R['clustering'] = {'k': kbest, 'silhouette': float(sc), 'sil_curve': sil_scores,
                   'bootstrap_ari_mean': float(np.mean(aris)), 'bootstrap_ari_sd': float(np.std(aris)),
                   'sizes': feat.cluster.value_counts().sort_index().to_dict(),
                   'region_mix': pd.crosstab(feat.cluster, feat.who_region).to_dict()}
print('F. clustering done: k=%d silhouette=%.3f ARI=%.2f±%.2f' % (kbest, sc, np.mean(aris), np.std(aris)))

# ---------- G. Panel regression per mechanism ----------
reg_rows = []
for cause in MECHS + ['Unintentional injuries']:
    d = panel[panel.cause == cause].dropna(subset=['asdr', 'gdp_pc', 'urban_pct', 'pop65_pct', 'alcohol', 'health_exp', 'internet']).copy()
    d = d[d.asdr > 0]
    d['la'] = np.log(d.asdr)
    d['lg'] = np.log(d.gdp_pc / 1000)
    d['yr'] = d.year - 2000
    m = smf.ols('la ~ lg + urban_pct + pop65_pct + alcohol + health_exp + internet + yr + C(iso3)', data=d).fit()
    mc = m.get_robustcov_results(cov_type='cluster', groups=d.iso3.values)
    names = list(m.params.index)
    for v in ['lg', 'urban_pct', 'pop65_pct', 'alcohol', 'health_exp', 'internet', 'yr']:
        i = names.index(v)
        reg_rows.append({'cause': cause, 'var': v, 'coef': float(mc.params[i]),
                         'se': float(mc.bse[i]), 'ci_low': float(mc.conf_int()[i][0]),
                         'ci_high': float(mc.conf_int()[i][1]),
                         'p': float(mc.pvalues[i]), 'n': int(m.nobs), 'r2': float(m.rsquared)})
regdf = pd.DataFrame(reg_rows)
regdf.to_csv(os.path.join(RES, 'panel_regression.csv'), index=False)
R['panel_reg'] = regdf.to_dict('records')
print('G. panel regression done, mechanisms:', regdf.cause.nunique())

# ---------- H. 2030 scenarios ----------
# H1: global unintentional ASDR trend (population-weighted global series) & bootstrap projection
series = []
for yr in [2000, 2010, 2015, 2019, 2020, 2021]:
    d = panel[(panel.year == yr) & (panel.cause == 'Unintentional injuries')].dropna(subset=['asdr', 'ghe_pop_000'])
    series.append({'year': yr, 'asdr_w': float(np.average(d.asdr, weights=d.ghe_pop_000)),
                   'deaths_000': float(d.deaths_000.sum()), 'pop_000': float(d.ghe_pop_000.sum())})
ser = pd.DataFrame(series)
x = ser.year.values; y = np.log(ser.asdr_w.values)
sl, ic, r, p, se = stats.linregress(x, y)
# bootstrap
boots = []
for b in range(1000):
    resid = y - (ic + sl * x)
    yb = ic + sl * x + rng.choice(resid, len(resid), replace=True)
    bb = np.polyfit(x, yb, 1)
    boots.append(np.exp(np.polyval(bb, 2030)))
ser['loglin_slope'] = sl
R['global_series'] = ser.to_dict('records')
R['projection_trend'] = {'slope_per_year': float(sl), 'arrr_pct': float((1 - np.exp(sl)) * 100),
                         'asdr_2030': float(np.exp(ic + sl * 2030)),
                         'asdr_2030_ci': [float(np.percentile(boots, 2.5)), float(np.percentile(boots, 97.7))],
                         'r2': float(r**2), 'p': float(p)}
# deaths at 2030 with 2021 population held constant (rate-only counterfactual, stated assumption)
pop21 = ser[ser.year == 2021].pop_000.iloc[0]  # thousands
d21 = ser[ser.year == 2021].deaths_000.iloc[0]
R['projection_trend']['deaths_2030_rateonly_000'] = R['projection_trend']['asdr_2030'] * pop21 / 100 / 1000
R['projection_trend']['deaths_2030_ci_000'] = [float(np.percentile(boots, 2.5)) * pop21 / 100 / 1000,
                                               float(np.percentile(boots, 97.7)) * pop21 / 100 / 1000]
R['projection_trend']['deaths_2021_000'] = float(d21)

# H2: achievable scenario: apply each country's top-quartile ARRR (2015-2021) to 2021 ASDR -> 2030
sdg = pd.read_csv(os.path.join(RES, 'sdg_road_country.csv'))
d = panel[(panel.year == 2021)].dropna(subset=['asdr']).copy()
arr = d.pivot_table(index='iso3', columns='cause', values='asdr')
dp = d.pivot_table(index='iso3', columns='cause', values='deaths_000')
popc = d.drop_duplicates('iso3').set_index('iso3').ghe_pop_000
q75_arrr = {}
ach = {}
for cause in MECHS + ['Unintentional injuries']:
    dsub = panel[panel.cause == cause].dropna(subset=['asdr'])
    a15 = dsub[dsub.year == 2015].set_index('iso3').asdr
    a21 = dsub[dsub.year == 2021].set_index('iso3').asdr
    common = a15.index.intersection(a21.index)
    arrr = 1 - (a21.loc[common] / a15.loc[common]) ** (1 / 6)
    q75 = arrr.quantile(0.75)
    q75_arrr[cause] = float(q75 * 100)
    a30 = a21 * (1 - q75) ** 9
    deaths30_000 = (a30 * popc.reindex(a30.index) / 100).sum() / 1000
    base21 = dp[cause].sum() if cause in dp else np.nan
    ach[cause] = {'top_quartile_arrr_pct': float(q75 * 100),
                  'deaths_2030_achievable_000': float(deaths30_000),
                  'deaths_2021_000': float(base21),
                  'averted_000': float(base21 - deaths30_000)}
R['achievable'] = ach
# H3: road injury SDG-aligned: 4.52%/yr from 2021 to 2030 for all countries
road21 = dp['Road injury']
a30r = arr['Road injury'] * (1 - 0.0452) ** 9
deaths30_road_000 = (a30r * popc.reindex(a30r.index) / 100).sum() / 1000
R['sdg_aligned_road'] = {'arrr_pct': 4.52, 'deaths_2030_000': float(deaths30_road_000),
                         'deaths_2021_000': float(road21.sum()), 'averted_000': float(road21.sum() - deaths30_road_000)}
print('H. projection done. 2030 ASDR %.2f [%.2f, %.2f]; road 2030 %.0fk averted %.0fk' % (
    R['projection_trend']['asdr_2030'], *R['projection_trend']['asdr_2030_ci'],
    R['sdg_aligned_road']['deaths_2030_000'], R['sdg_aligned_road']['averted_000']))

json.dump(R, open(os.path.join(RES, 'core_results.json'), 'w'), indent=1, default=str)
print('saved F+G+H')
