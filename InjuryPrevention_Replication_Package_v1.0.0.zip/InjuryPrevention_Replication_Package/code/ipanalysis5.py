"""Regenerate Table 1 with WHO official global aggregates (deaths + YLL from global files)."""
import pandas as pd, numpy as np, os, json

PROC = r'ipdata/proc'
RES = r'ipdata/results'
R = json.load(open(os.path.join(RES, 'core_results.json')))

MECHS = ['Road injury', 'Poisonings', 'Falls', 'Fire, heat and hot substances', 'Drowning',
         'Exposure to mechanical forces', 'Natural disasters', 'Other unintentional injuries']
gd = pd.read_csv(os.path.join(PROC, 'ghe_global_deaths_series.csv'))
gy = pd.read_csv(os.path.join(PROC, 'ghe_global_yll_series.csv'))
age21 = pd.read_csv(os.path.join(PROC, 'ghe_agegroup_2021.csv'))
age21 = age21[age21.sex == 'Persons']
AGE_MID = {'0-4': 2.5, '5-14': 10, '15-29': 22.5, '30-49': 40, '50-59': 55, '60-69': 65, '70+': 77.5}

rows = []
for cause in ['Unintentional injuries'] + MECHS:
    rec = {'cause': cause}
    for yr in [2000, 2021]:
        rec[f'deaths_{yr}'] = gd[(gd.year == yr) & (gd.cause == cause) & (gd.sex == 'Both sexes')].deaths_000.iloc[0]
        rec[f'deaths_m_{yr}'] = gd[(gd.year == yr) & (gd.cause == cause) & (gd.sex == 'Male')].deaths_000.iloc[0]
        rec[f'deaths_f_{yr}'] = gd[(gd.year == yr) & (gd.cause == cause) & (gd.sex == 'Female')].deaths_000.iloc[0]
        rec[f'yll_{yr}'] = gy[(gy.year == yr) & (gy.cause == cause) & (gy.sex == 'Both sexes')].yll_000.iloc[0]
    rec['deaths_pct_change'] = (rec['deaths_2021'] / rec['deaths_2000'] - 1) * 100
    rec['yll_pct_change'] = (rec['yll_2021'] / rec['yll_2000'] - 1) * 100
    rec['yll_per_death_2021'] = rec['yll_2021'] / rec['deaths_2021']
    rec['mf_ratio_2021'] = rec['deaths_m_2021'] / rec['deaths_f_2021']
    rows.append(rec)
summ = pd.DataFrame(rows)
# ASDR (population-weighted, country-level) — use country sums (documented)
panel = pd.read_csv(os.path.join(PROC, 'panel_persons.csv'))
for yr in [2000, 2021]:
    sub = panel[panel.year == yr].dropna(subset=['asdr', 'ghe_pop_000'])
    w = sub.groupby('cause').apply(lambda g: np.average(g.asdr, weights=g.ghe_pop_000), include_groups=False)
    for cause in summ.cause:
        summ.loc[summ.cause == cause, f'asdr_{yr}'] = w.get(cause, np.nan)
summ['asdr_pct_change'] = (summ['asdr_2021'] / summ['asdr_2000'] - 1) * 100
tot = summ.loc[summ.cause == 'Unintentional injuries', 'deaths_2021'].iloc[0]
summ['share_of_unint_2021'] = summ.deaths_2021 / tot * 100
# mean age at death 2021 (country-sum age groups, Persons)
ma = []
for cause in summ.cause:
    sub = age21[age21.cause == cause]
    d = sub.groupby('age_group').deaths_000.sum()
    m = sum(d.get(k, 0) * v for k, v in AGE_MID.items()) / d.sum()
    ma.append({'cause': cause, 'mean_age_death_2021': m})
summ = summ.merge(pd.DataFrame(ma), on='cause', how='left')
summ.to_csv(os.path.join(RES, 'table1_mechanism_summary.csv'), index=False)
R['table1'] = summ.to_dict('records')
json.dump(R, open(os.path.join(RES, 'core_results.json'), 'w'), indent=1, default=str)
print(summ[['cause', 'deaths_2000', 'deaths_2021', 'deaths_pct_change', 'asdr_2000', 'asdr_2021',
            'asdr_pct_change', 'yll_2021', 'yll_pct_change', 'yll_per_death_2021', 'share_of_unint_2021',
            'mf_ratio_2021', 'mean_age_death_2021']].round(2).to_string(index=False))
