"""Patch analysis2: add GDP-decile mechanism ASDR curves + falls/road crossing; fix natural disasters in scenarios."""
import pandas as pd, numpy as np, os, json

PROC = r'ipdata/proc'
RES = r'ipdata/results'
R = json.load(open(os.path.join(RES, 'core_results.json')))

MECHS = ['Road injury', 'Poisonings', 'Falls', 'Fire, heat and hot substances', 'Drowning',
         'Exposure to mechanical forces', 'Natural disasters', 'Other unintentional injuries']
panel = pd.read_csv(os.path.join(PROC, 'panel_persons.csv'))

# GDP decile binned ASDR curves (population-weighted), 2021
c21 = panel[(panel.year == 2021) & panel.cause.isin(MECHS)].dropna(subset=['asdr', 'gdp_pc']).copy()
c21['gdec'] = pd.qcut(c21.gdp_pc, 10, labels=False)
rows = []
for (dec, cause), g in c21.groupby(['gdec', 'cause']):
    gg = g.dropna(subset=['asdr', 'ghe_pop_000'])
    rows.append({'gdec': dec, 'mechanism': cause,
                 'median_gdp': float(g.gdp_pc.median()),
                 'asdr_w': float(np.average(gg.asdr, weights=gg.ghe_pop_000))})
curves = pd.DataFrame(rows)
curves.to_csv(os.path.join(RES, 'gdp_decile_asdr_curves.csv'), index=False)

# falls vs road injury share of unintentional deaths by GDP decile
u = c21[c21.cause == 'Unintentional injuries'] if (c21.cause == 'Unintentional injuries').any() else None
panel_u = panel[(panel.year == 2021) & (panel.cause == 'Unintentional injuries')][['iso3', 'gdp_pc', 'deaths_000']]
umap = panel_u.dropna(subset=['gdp_pc']).copy()
sh = c21.merge(umap[['iso3', 'deaths_000']].rename(columns={'deaths_000': 'u_deaths'}), on='iso3', how='left')
sh['u_deaths'] = sh['u_deaths'].fillna(0)
sh = sh.rename(columns={'cause': 'mechanism'})
cross = sh.groupby(['gdec', 'mechanism']).apply(
    lambda g: g.deaths_000.sum() / g.u_deaths.sum() * 100, include_groups=False).unstack()
cross['median_gdp'] = sh.groupby('gdec').gdp_pc.median()
cross.to_csv(os.path.join(RES, 'gdp_decile_shares.csv'))
print(cross[['Road injury', 'Falls', 'median_gdp']].round(1).to_string())
print('====')

# fix cluster CDR + save (recompute cluster profiles cdr properly)
cl = pd.read_csv(os.path.join(RES, 'clusters_2021.csv'), index_col=0)
prof = pd.read_csv(os.path.join(RES, 'cluster_profiles.csv'))
# recompute cdr from panel
c21u = panel[(panel.year == 2021) & (panel.cause == 'Unintentional injuries')].merge(
    cl[['cluster']], left_on='iso3', right_index=True, how='inner', suffixes=('', '_cl'))
cdr = c21u.groupby('cluster').apply(
    lambda g: g.deaths_000.sum() / g.ghe_pop_000.sum() * 100000, include_groups=False)
prof['unint_cdr'] = prof.cluster.map(cdr)
prof.to_csv(os.path.join(RES, 'cluster_profiles.csv'), index=False)
print(prof[['cluster', 'n_countries', 'unint_cdr', 'mean_gdp', 'mean_pop65']].round(2).to_string(index=False))

# fix achievable scenario: exclude natural disasters (deaths ~0 -> unstable ARRR)
ach = R['achievable']
ach.pop('Natural disasters', None)
tot2021 = sum(v['deaths_2021_000'] for k, v in ach.items() if k != 'Unintentional injuries')
tot2030 = sum(v['deaths_2030_achievable_000'] for k, v in ach.items() if k != 'Unintentional injuries')
averted = tot2021 - tot2030
R['achievable_total'] = {'deaths_2021_000_excl_natdis': tot2021,
                         'deaths_2030_achievable_000_excl_natdis': tot2030,
                         'averted_000': averted}
R['achievable'] = ach
json.dump(R, open(os.path.join(RES, 'core_results.json'), 'w'), indent=1, default=str)
print('patched. Achievable scenario excludes natural disasters: 2021=%.1fk -> 2030=%.1fk, averted %.1fk' % (
    tot2021, tot2030, averted))
