"""Run the main analysis chain (ipanalysis1-4) from the repository root."""
import subprocess, sys, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CODE = os.path.join(ROOT, 'code')
os.chdir(ROOT)
for script in ['ipanalysis1.py', 'ipanalysis2.py', 'ipanalysis3.py', 'ipanalysis4.py']:
    print('=' * 20, script, flush=True)
    r = subprocess.run([sys.executable, os.path.join(CODE, script)],
                       capture_output=True, text=True, timeout=3000)
    print(r.stdout[-3000:])
    if r.returncode != 0:
        print('STDERR:', r.stderr[-2000:])
        sys.exit(f'{script} FAILED')
print('ALL DONE')
