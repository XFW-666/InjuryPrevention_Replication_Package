# -*- coding: utf-8 -*-
"""Merge GSRRS 2018 policy indicators with the mortality panel (merge only)."""
import pandas as pd, numpy as np, os, re

PROC = r'ipdata/proc'
RES = r'ipdata/results'

panel = pd.read_csv(os.path.join(PROC, 'panel_persons.csv'))
_cn = pd.read_csv(os.path.join(PROC, 'ghe_deaths_long.csv'))[['iso3', 'country']].drop_duplicates('iso3')
pol = pd.read_csv(os.path.join(PROC, 'policy', 'policy_indicators_2018.csv'))

name2iso = dict(zip(_n.country.str.lower() if False else _cn.country.str.lower(), _cn.iso3))
alias = {
    'united states of america': 'USA', 'russia': 'RUS', "democratic people\u2019s republic of korea": 'PRK',
    'republic of korea': 'KOR', 'democratic republic of the congo': 'COD', 'republic of the congo': 'COG',
    'united republic of tanzania': 'TZA', 'iran (islamic republic of)': 'IRN',
    'bolivia (plurinational state of)': 'BOL', 'venezuela (bolivarian republic of)': 'VEN',
    'micronesia (federated states of)': 'FSM', 'republic of moldova': 'MDA',
    'the former yugoslav republic of macedonia': 'MKD', 'libyan arab jamahiriya': 'LBY',
    'syrian arab republic': 'SYR', 'united kingdom of great britain and northern ireland': 'GBR',
    'czech republic': 'CZE', 'cabo verde': 'CPV', 'swaziland': 'SWZ',
    'c\u00f4te d\u2019ivoire': 'CIV', 'cote d\u2019ivoire': 'CIV', 'cote divoire': 'CIV', 'viet nam': 'VNM',
    'brunei darussalam': 'BRN', "lao people\u2019s democratic republic": 'LAO', 'state of palestine': 'PSE',
    'netherlands (kingdom of the)': 'NLD', 'china, hong kong sar': 'HKG', 'china, macao sar': 'MAC',
}
def match(n):
    k = str(n).strip().lower()
    if k in name2iso:
        return name2iso[k]
    if k in alias:
        return alias[k]
    for nm, iso in name2iso.items():
        if nm.startswith(k[:18]):
            return iso
    return None

pol['iso3'] = pol.country_gsrrs.map(match)
print('matched', pol.iso3.notna().sum(), '/', len(pol))
print('unmatched:', pol[pol.iso3.isna()].country_gsrrs.tolist())

road = panel[panel.cause == 'Road injury']
r15 = road[road.year == 2015][['iso3', 'asdr', 'gdp_pc', 'pop65_pct', 'who_region']].rename(
    columns={'asdr': 'asdr15', 'gdp_pc': 'gdp15', 'pop65_pct': 'pop65_15'})
r21 = road[road.year == 2021][['iso3', 'asdr', 'gdp_pc', 'pop65_pct']].rename(
    columns={'asdr': 'asdr21', 'gdp_pc': 'gdp21', 'pop65_pct': 'pop65_21'})
u21 = panel[(panel.cause == 'Unintentional injuries') & (panel.year == 2021)][['iso3', 'asdr']].rename(columns={'asdr': 'u21'})
m = pol.merge(r15, on='iso3', how='inner').merge(r21, on='iso3', how='inner').merge(u21, on='iso3', how='left')
m['arrr'] = (1 - (m.asdr21 / m.asdr15) ** (1 / 6)) * 100
m['lgdp'] = np.log(m.gdp21 / 1000)
m['lbasdr'] = np.log(m.asdr15.replace(0, np.nan))
m.to_csv(os.path.join(RES, 'policy_mortality_merged.csv'), index=False)
print('merged saved:', len(m), 'countries')
