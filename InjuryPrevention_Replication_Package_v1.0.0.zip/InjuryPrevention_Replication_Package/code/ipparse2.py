"""Parse age-group sheets (2000 & 2021 deaths + age-group populations) for decomposition."""
import pandas as pd, os, sys
from ipparse import parse_wide  # reuse parser

OUT = r'ipdata/raw'
PROC = r'ipdata/proc'
AGE_SHEETS = ['0-4', '5-14', '15-29', '30-49', '50-59', '60-69', '70+']

def parse_age_population(path, sheet):
    d = pd.read_excel(path, sheet_name=sheet, header=None)
    row_pop = None
    for i in range(len(d)):
        if str(d.iloc[i, 3]).strip().startswith('Population'):
            row_pop = i
            break
    recs = []
    for c in range(7, d.shape[1]):
        iso = d.iloc[7, c]
        if isinstance(iso, str) and len(iso.strip()) == 3 and iso.strip().isalpha():
            nm = d.iloc[6, c]
            v = d.iloc[row_pop, c] if row_pop else None
            if isinstance(v, (int, float)) and not pd.isna(v):
                recs.append((iso.strip(), str(nm).strip(), float(v)))
    return pd.DataFrame(recs, columns=['iso3', 'country', 'population_000'])

# deaths by age group: 2000 and 2021
allf = []
pops = []
for yr, fn in [(2000, 'ghe2021_deaths_bycountry_2000.xlsx'), (2021, 'ghe2021_deaths_bycountry_2021.xlsx')]:
    for s in AGE_SHEETS:
        df = parse_wide(os.path.join(OUT, fn), s, 'deaths_000')
        df['age_group'] = s
        df['year'] = yr
        allf.append(df)
        pt = parse_age_population(os.path.join(OUT, fn), s)
        pt['age_group'] = s
        pt['year'] = yr
        pops.append(pt)
        print(yr, s, len(df), flush=True)

pd.concat(allf, ignore_index=True).to_csv(os.path.join(PROC, 'ghe_agegroup_2000_2021.csv'), index=False)
pd.concat(pops, ignore_index=True).to_csv(os.path.join(PROC, 'ghe_agegroup_population.csv'), index=False)
print('DONE')
