"""Analyses C-H: injury transition, inequality, SDG, clustering, panel regression, projection."""
import pandas as pd, numpy as np, os, json
from scipy import stats
import statsmodels.formula.api as smf

PROC = r'ipdata/proc'
RES = r'ipdata/results'
R = json.load(open(os.path.join(RES, 'core_results.json')))
rng = np.random.default_rng(20240920)

MECHS = ['Road injury', 'Poisonings', 'Falls', 'Fire, heat and hot substances', 'Drowning',
         'Exposure to mechanical forces', 'Natural disasters', 'Other unintentional injuries']
panel = pd.read_csv(os.path.join(PROC, 'panel_persons.csv'))
# attach country names
_cn = pd.read_csv(os.path.join(PROC, 'ghe_deaths_long.csv'))[['iso3', 'country']].drop_duplicates('iso3')
panel = panel.merge(_cn, on='iso3', how='left')

# ---------- C. Injury transition ----------
# C1: cross-sectional 2021 fits: log(ASDR) ~ spline(log10 GDP pc), population-weighted
c21 = panel[(panel.year == 2021) & panel.cause.isin(MECHS + ['Unintentional injuries'])].dropna(subset=['asdr', 'gdp_pc'])
trans = {}
for cause in MECHS + ['Unintentional injuries']:
    d = c21[c21.cause == cause].copy()
    d = d[d.asdr > 0]
    d['lg'] = np.log10(d.gdp_pc)
    d['lam'] = np.asarray(d.asdr)
    d['w'] = d.ghe_pop_000 / d.ghe_pop_000.sum()
    X = np.column_stack([np.ones(len(d)), d.lg, d.lg**2, d.lg**3])
    W = d.w.values
    beta, *_ = np.linalg.lstsq(X * W[:, None], d.lam * W, rcond=None)
    grid = np.linspace(d.lg.min(), d.lg.max(), 200)
    Xg = np.column_stack([np.ones(200), grid, grid**2, grid**3])
    fit = Xg @ beta
    # income at peak of fitted curve
    xi = np.linspace(2.6, 4.7, 400)
    Xp = np.column_stack([np.ones(400), xi, xi**2, xi**3])
    fp = Xp @ beta
    peak_x = xi[np.argmax(fp)]
    trans[cause] = {
        'fitted_lgasdr': {'beta': beta.tolist(), 'gdp_grid': (10**grid).tolist(), 'fit': fit.tolist()},
        'peak_gdp_2021usd': float(10**peak_x),
        'peak_asdr': float(np.max(fp)),
        'n': int(len(d)),
    }
# C2: shares by GDP quintile (population-weighted, 2021)
c21u = c21[c21.cause == 'Unintentional injuries'].copy()
quint = c21u.groupby('iso3').deaths_000.sum().rename('u_deaths').reset_index()
qmap = c21u[['iso3', 'gdp_pc', 'ghe_pop_000']].drop_duplicates()
qmap['quintile'] = pd.qcut(qmap.gdp_pc, 5, labels=['Q1 (poorest)', 'Q2', 'Q3', 'Q4', 'Q5 (richest)'])
share_rows = []
for mech in MECHS:
    d = c21[c21.cause == mech][['iso3', 'deaths_000']]
    m = qmap.merge(quint[['iso3', 'u_deaths']], on='iso3', how='left').merge(d, on='iso3', how='left')
    m['mech_deaths'] = m.deaths_000.fillna(0)
    for q, g in m.groupby('quintile', observed=True):
        share_rows.append({'mechanism': mech, 'quintile': q,
                           'mech_share': g.mech_deaths.sum() / g.u_deaths.sum() * 100,
                           'mech_cdr': g.mech_deaths.sum() / g.ghe_pop_000.sum() * 100})
shares = pd.DataFrame(share_rows)
shares.to_csv(os.path.join(RES, 'gdp_quintile_shares.csv'), index=False)
# C3: within-country transition elasticity (country FE, 2000-2021)
rows = []
for cause in MECHS + ['Unintentional injuries']:
    d = panel[(panel.cause == cause)].dropna(subset=['asdr', 'gdp_pc']).copy()
    d = d[d.asdr > 0]
    d['la'] = np.log(d.asdr)
    d['lg'] = np.log(d.gdp_pc / 1000)
    d['yr'] = d.year - 2000
    m = smf.ols('la ~ lg + yr + C(iso3)', data=d).fit()
    # cluster-robust by country
    try:
        mc = m.get_robustcov_results(cov_type='cluster', groups=d.iso3.values)
        beta_lg = mc.params[list(m.params.index).index('lg')]
        se = mc.bse[list(m.params.index).index('lg')]
        ci = mc.conf_int()[list(m.params.index).index('lg')]
    except Exception:
        beta_lg, se = m.params['lg'], m.bse['lg']; ci = m.conf_int().loc['lg']
    rows.append({'cause': cause, 'lgdp_coef': float(beta_lg), 'se': float(se),
                 'ci_low': float(ci[0]), 'ci_high': float(ci[1]), 'n': len(d)})
elast = pd.DataFrame(rows)
elast.to_csv(os.path.join(RES, 'transition_elasticity.csv'), index=False)
R['transition'] = trans
R['elasticity'] = elast.to_dict('records')
print('C. transition done. Elasticity (unintentional):', round(elast[elast.cause=='Unintentional injuries'].lgdp_coef.iloc[0], 3))

# ---------- D. Inequality: concentration index ----------
def conc_index(df, h, w):
    df = df.sort_values('gdp_pc').reset_index(drop=True)
    h_ = df[h].values; w_ = df[w].values
    n = len(df)
    cum_w = np.cumsum(w_) / w_.sum()
    ranks = (cum_w + (cum_w - w_ / w_.sum())) / 2  # midpoint share
    mu = np.average(h_, weights=w_)
    cov = np.cov(h_, ranks, aweights=w_)[0, 1]
    return 2 / mu * cov, mu

ineq_rows = []
for yr in [2000, 2019, 2021]:
    d = panel[(panel.year == yr) & (panel.cause == 'Unintentional injuries')].dropna(subset=['yll_000', 'gdp_pc'])
    d = d.copy()
    d['rate'] = d.yll_000 / d.ghe_pop_000 * 100
    ci, mu = conc_index(d, 'rate', 'ghe_pop_000')
    # SII: regression of rate on relative rank (midpoint), population weighted
    d2 = d.sort_values('gdp_pc').reset_index(drop=True)
    cum_w = np.cumsum(d2.ghe_pop_000) / d2.ghe_pop_000.sum()
    d2['rank'] = (cum_w + (cum_w - d2.ghe_pop_000 / d2.ghe_pop_000.sum())) / 2
    X = np.column_stack([np.ones(len(d2)), d2['rank']])
    W = np.sqrt(d2.ghe_pop_000.values)
    bb, *_ = np.linalg.lstsq(X * W[:, None], d2['rate'] * W, rcond=None)
    ineq_rows.append({'year': yr, 'CI': float(ci), 'mean_rate': float(mu),
                      'sii_slope': float(bb[1]), 'sii_intercept': float(bb[0]), 'n': len(d2)})
ineq = pd.DataFrame(ineq_rows)
ineq.to_csv(os.path.join(RES, 'inequality_unintentional.csv'), index=False)
# concentration curve points for plotting (2000 vs 2021)
cc = {}
for yr in [2000, 2021]:
    d = panel[(panel.year == yr) & (panel.cause == 'Unintentional injuries')].dropna(subset=['yll_000', 'gdp_pc'])
    d = d.sort_values('gdp_pc').reset_index(drop=True)
    d['rate'] = d.yll_000 / d.ghe_pop_000 * 100
    cum_w = np.cumsum(d.ghe_pop_000) / d.ghe_pop_000.sum()
    cum_h = np.cumsum(d.rate * d.ghe_pop_000) / np.sum(d.rate * d.ghe_pop_000)
    cc[str(yr)] = {'rank': cum_w.tolist(), 'cum_share': cum_h.tolist()}
# per-mechanism CI in 2021
mech_ci = []
for mech in MECHS:
    d = panel[(panel.year == 2021) & (panel.cause == mech)].dropna(subset=['yll_000', 'gdp_pc'])
    d['rate'] = d.yll_000 / d.ghe_pop_000 * 100
    ci, mu = conc_index(d, 'rate', 'ghe_pop_000')
    mech_ci.append({'mechanism': mech, 'CI_2021': float(ci)})
R['inequality'] = {'by_year': ineq.to_dict('records'), 'curve': cc, 'mech_ci': mech_ci}
print('D. inequality done:', {r['year']: round(r['CI'], 4) for r in ineq.to_dict('records')})

# ---------- E. SDG 3.6.1 assessment (road injury) ----------
REQ_ARRR = (1 - np.log(0.5) / 15)  # ~4.43%/yr
req_arrr = (np.log(0.5) / -15)
road = panel[panel.cause == 'Road injury'].dropna(subset=['asdr'])
r15 = road[road.year == 2015][['iso3', 'country', 'who_region', 'asdr', 'deaths_000', 'ghe_pop_000', 'gdp_pc']].rename(
    columns={'asdr': 'asdr_2015', 'deaths_000': 'deaths_2015_000', 'ghe_pop_000': 'pop_2015_000'})
r21 = road[road.year == 2021][['iso3', 'asdr', 'deaths_000', 'ghe_pop_000']].rename(
    columns={'asdr': 'asdr_2021', 'deaths_000': 'deaths_2021_000', 'ghe_pop_000': 'pop_2021_000'})
sdg = r15.merge(r21, on='iso3', how='inner')
sdg['arrr_obs'] = (1 - (sdg.asdr_2021 / sdg.asdr_2015) ** (1 / 6))
sdg['arrr_obs_pct'] = sdg.arrr_obs * 100
sdg['req_arrr_pct'] = (1 - 0.5 ** (1 / 15)) * 100
# SE of log ratio from Poisson approx on deaths
sdg['se_log'] = np.sqrt(1 / (sdg.deaths_2021_000 * 1000) + 1 / (sdg.deaths_2015_000 * 1000)) / 6
def classify(row):
    if row.arrr_obs_pct >= row.req_arrr_pct:
        return 'On track'
    if row.arrr_obs_pct > 0.5:
        return 'Progressing, insufficient'
    if row.arrr_obs_pct > -0.5:
        return 'Stagnant'
    return 'Worsening'
sdg['sdg_status'] = sdg.apply(classify, axis=1)
sdg.to_csv(os.path.join(RES, 'sdg_road_country.csv'), index=False)
# regional normalized trajectory 2000-2021 vs required path
road_all = road.dropna(subset=['asdr'])
reg_rows = []
for reg_, g in road_all.groupby('who_region'):
    for yr, gg in g.groupby('year'):
        dd_ = gg.dropna(subset=['asdr', 'ghe_pop_000'])
        asdr_w = np.average(dd_.asdr, weights=dd_.ghe_pop_000)
        reg_rows.append({'who_region': reg_, 'year': yr, 'asdr_w': asdr_w})
regtr = pd.DataFrame(reg_rows)
base15 = regtr[regtr.year == 2015].set_index('who_region').asdr_w
regtr['index_2015_100'] = regtr.apply(lambda r: r.asdr_w / base15.get(r.who_region, np.nan) * 100, axis=1)
regtr.to_csv(os.path.join(RES, 'sdg_road_region.csv'), index=False)
R['sdg'] = {'req_arrr_pct': float((1 - 0.5 ** (1 / 15)) * 100),
            'status_counts': sdg.sdg_status.value_counts().to_dict(),
            'on_track_n': int((sdg.sdg_status == 'On track').sum()),
            'n_countries': int(len(sdg))}
print('E. SDG done. Required ARRR %.2f%%/yr; on-track countries: %d / %d' % (
    R['sdg']['req_arrr_pct'], R['sdg']['on_track_n'], R['sdg']['n_countries']))

json.dump(R, open(os.path.join(RES, 'core_results.json'), 'w'), indent=1, default=str)
print('saved C+D+E')
