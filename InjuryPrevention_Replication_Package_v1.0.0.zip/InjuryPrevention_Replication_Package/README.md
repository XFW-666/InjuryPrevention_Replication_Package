# Replication package: global mechanism-specific decomposition of unintentional-injury mortality, 2000-2021

Data and analysis code for the manuscript *"The changing anatomy of unintentional injury: a global
mechanism-specific decomposition of mortality and years of life lost, 2000-2021"*.

All inputs are public aggregate statistics; no individual-level microdata were used.

## Data sources

1. **WHO Global Health Estimates 2021** - deaths, years of life lost (YLL) and age-standardised death
   rates (ASDR) by cause, age, sex, country and year, 2000-2021, for 185 countries and areas.
2. **World Bank World Development Indicators** - GDP per capita (PPP), urbanisation, population aged 65+,
   alcohol consumption, health expenditure, physicians and internet use (country-year, 2000-2021).
3. **WHO Global status report on road safety 2018** - statistical annex with country road-safety
   legislation indicators (eight best-practice items) for 175 countries.

Direct download URLs and the SHA-256 checksum of every source file are listed in
[`DATA_SOURCES.md`](DATA_SOURCES.md) and [`SHA256SUMS_sources.txt`](SHA256SUMS_sources.txt).
Two small source workbooks and the World Bank API responses used by the analysis are included under
`ipdata/raw/`; the remaining source files can be re-downloaded from the listed URLs and verified
against their checksums.

## Repository layout

```
code/                     analysis pipeline (Python 3.12)
  ipparse*.py             parse GHE workbooks into tidy CSVs
  ipbuild.py              build the country-year-cause master panel
  ipanalysis1-5.py        decomposition, injury transition, inequality, SDG 3.6.1,
                          determinants, typology, validation, scenarios
  ippolicy_*.py           road-safety policy indicators, DiD and event-study analyses
  iptables.py             manuscript tables
  iprunall.py             runs the main analysis chain
ipdata/raw/               source files shipped with the package (see DATA_SOURCES.md for the rest)
ipdata/proc/              parsed analysis datasets (tidy CSV, incl. policy/ indicators)
ipdata/results/           intermediate results and manuscript table files
```

## Requirements

```bash
pip install -r requirements.txt   # pandas, numpy, scipy, statsmodels, scikit-learn, openpyxl, PyMuPDF
```

## Reproducing the analysis

Place the source files listed in `DATA_SOURCES.md` under `ipdata/raw/` (the two global-series
workbooks and the World Bank JSON responses are already included). Then, from the repository root:

```bash
python code/ipparse.py       # GHE wide sheets -> tidy CSVs
python code/ipparse2.py
python code/ipparse3.py
python code/ipbuild.py       # master panel
python code/iprunall.py      # main analyses 1-4
python code/ipanalysis5.py
python code/ippolicy_extract.py   # needs gsrrs2018.pdf in ipdata/raw
python code/ippolicy_build.py
python code/ippolicy_merge.py
python code/ippolicy_analysis2.py
python code/ippolicy_extras.py
python code/iptables.py
```

## Licenses

- Code: MIT (see `LICENSE`).
- WHO Global Health Estimates: © WHO, used per the WHO GHO data terms.
- World Bank indicators: CC-BY 4.0 (World Bank).
- WHO Global status report 2018: © WHO (CC BY-NC-ND 3.0 IGO); only derived indicator values are redistributed here.

## Citation

See `CITATION.cff`.
