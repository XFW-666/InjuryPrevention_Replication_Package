# Data sources and integrity

All analysis inputs are public. No microdata were used.

## World Health Organization Global Health Estimates 2021

Download page: https://www.who.int/data/gho/data/themes/mortality-and-global-health-estimates/ghe-leading-causes-of-death
Methods: https://cdn.who.int/media/docs/default-source/gho-documents/global-health-estimates/ghe2021_cod_methods.pdf

| File | URL | Size (MB) | SHA-256 |
|---|---|---|---|
| ghe2021_deaths_global_new2.xlsx | https://cdn.who.int/media/docs/default-source/gho-documents/global-health-estimates/ghe2021_deaths_global_new2.xlsx | 0.4 | `24a91daf1b5811604e4c5b104e9a1cbd20bffcc11c1ba9d4ea1e0f4083f0d4ee` |
| ghe2021_deaths_bycountry_2000.xlsx | https://cdn.who.int/media/docs/default-source/gho-documents/global-health-estimates/ghe2021_deaths_bycountry_2000.xlsx | 10.2 | `a9ab1511b491c2c814984ae13514ac7065fac239a7603e6af95d96fd91607bdc` |
| ghe2021_deaths_bycountry_2015.xlsx | https://cdn.who.int/media/docs/default-source/gho-documents/global-health-estimates/ghe2021_deaths_bycountry_2015.xlsx | 10.1 | `62d848e89c83a18b037a74d6414c2cda277c423ec5de1f6e1dd5d23771726301` |
| ghe2021_deaths_bycountry_2019.xlsx | https://cdn.who.int/media/docs/default-source/gho-documents/global-health-estimates/ghe2021_deaths_bycountry_2019.xlsx | 10.2 | `ef53fd31f7af37f522f0025e99d0c69624c9da07e29074a907abcff9d62f4239` |
| ghe2021_deaths_bycountry_2021.xlsx | https://cdn.who.int/media/docs/default-source/gho-documents/global-health-estimates/ghe2021_deaths_bycountry_2021.xlsx | 10.2 | `1f593b791db8a9408fdce1973ef2b16b4cd5c9cf8e1838b661e0be9ffa5b7418` |
| ghe2021_deaths_bycountry_age_sex_2010_new.xlsx | https://cdn.who.int/media/docs/default-source/gho-documents/global-health-estimates/ghe2021_deaths_bycountry_age_sex_2010_new.xlsx | 10.1 | `06d5609e5e7d74b8390c143831e7c1e77c2af33f6e6d6fee8c9a7f5562acd713` |
| ghe2021_deathrates_bycountry_asdr.xlsx | https://cdn.who.int/media/docs/default-source/gho-documents/global-health-estimates/ghe2021_deathrates_bycountry_asdr.xlsx | 8.6 | `3c87314a348384b7de86e4f5c3b5534637bb6f5982897df2812bd106c05cb863` |
| ghe2021_deathrates_bycountry_cdr.xlsx | https://cdn.who.int/media/docs/default-source/gho-documents/global-health-estimates/ghe2021_deathrates_bycountry_cdr.xlsx | 8.6 | `dbb22132411aa5b6191d51bcb88697ab6752416e1ecb50c75e62bbda7e090daa` |
| ghe2021_yll_global_new.xlsx | https://cdn.who.int/media/docs/default-source/gho-documents/global-health-estimates/ghe2021_yll_global_new.xlsx | 0.4 | `642d8f6c55a2ec69620f6979e4671314bceca149575b6c284145565ed83e858b` |
| ghe2021_yll_bycountry_2000.xlsx | https://cdn.who.int/media/docs/default-source/gho-documents/global-health-estimates/ghe2021_yll_bycountry_2000.xlsx | 10.2 | `bc9db73936ef2b1b2a19f550dc29233ab316ede35bcb4c565ff31165c4e63f0b` |
| ghe2021_yll_bycountry_2019.xlsx | https://cdn.who.int/media/docs/default-source/gho-documents/global-health-estimates/ghe2021_yll_bycountry_2019.xlsx | 9.9 | `27494eedb3208ea848a292831e5decede556dbbff68434e77076367e6fc3d624` |
| ghe2021_yll_bycountry_2021.xlsx | https://cdn.who.int/media/docs/default-source/gho-documents/global-health-estimates/ghe2021_yll_bycountry_2021.xlsx | 10.3 | `36061393782c031843522eb88ef3f9ce3b8eab6a2cb48fb4d5f04d693e7f673b` |
| ghe2021_daly_bycountry_2000.xlsx | https://cdn.who.int/media/docs/default-source/gho-documents/global-health-estimates/ghe2021_daly_bycountry_2000.xlsx | 12.8 | `a051da530e7802ff6c084293b50e8de21cce0c36f02b76085568487f143246fe` |
| ghe2021_daly_bycountry_2021.xlsx | https://cdn.who.int/media/docs/default-source/gho-documents/global-health-estimates/ghe2021_daly_bycountry_2021.xlsx | 12.8 | `55cd83a0c11de8cbc163b09bbe7880f5b22ae1f2c63e31b949565fd412ffb464` |
| world_johan.geojson | https://raw.githubusercontent.com/johan/world.geo.json/master/countries.geo.json | 0.3 | `bc2356a26a2976f98e4aaf1b24c5693d5a4dc9b6178aeb952dbafbcd42c73bcd` |

## World Bank World Development Indicators

Retrieved via https://api.worldbank.org/v2/ (accessed 2026-09-20). Indicators: SP.POP.TOTL, SP.POP.65UP.TO.ZS, SP.POP.0014.TO.ZS, SP.POP.1564.TO.ZS, NY.GDP.PCAP.PP.CD, SP.URB.TOTL.IN.ZS, SH.ALC.PCAP.LI, SH.XPD.CHEX.GD.ZS, SH.MED.PHYS.ZS, IT.NET.USER.ZS, SP.DYN.LE00.IN, NY.GNP.PCAP.CD.

## UN SDG Global Database

https://unstats.un.org/sdgs/indicators/database/ (indicator 3.6.1, accessed for cross-checking).

## Derived analysis files

| File | Description |
|---|---|
| data/panel_country_year_cause.csv | country x year x cause panel: deaths, YLL, ASDR, population, covariates, WHO region |
| data/global_deaths_series.csv | WHO global deaths and age-group series, 2000-2021 |
| tables/*.csv | all table and intermediate result files |

## Software

Python 3.12; pandas, NumPy, SciPy, statsmodels, scikit-learn, matplotlib. Analysis code in `code/`.

## WHO Global status report on road safety (policy data)

| File | Size (MB) | SHA-256 |
|---|---|---|
| gsrrs2018.pdf | 9.4 | `e396073710d191f1e77af0fb69b5444a8c888d0fb2f9fa4be5f92036226bc2d5` |
| gsrrs2023.pdf | 4.5 | `8d65d10d3b8cbc018fb4701130fad953425699104c6560c7aee5308e5890e2b5` |